import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CounntNumReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
    private IntWritable result = new IntWritable();		// as writable part is integer, using IntWritable (serialising and deserialising the data)

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        int total = 0;
        for (IntWritable value : values) {			// running loop on values and key shared by map function over context
            total += value.get();					// we run a loop on the values we get from mapper and then add the total of it by taking individual card number
        }
        result.set(total);
        context.write(key, result);			// setting the context with results
    }
}
	