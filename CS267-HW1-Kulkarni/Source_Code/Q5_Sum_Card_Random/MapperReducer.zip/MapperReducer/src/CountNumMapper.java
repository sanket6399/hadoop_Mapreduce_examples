import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CountNumMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
    private Text suit = new Text();
    private IntWritable value = new IntWritable();				//as writable part is integer, using IntWritable (serialising and deserialising the data)

    @Override
    protected void map(LongWritable key, Text line, Context context) throws IOException, InterruptedException {		//following naming conventions of hadoop framework
        String[] splits = line.toString().split(" ");			// so in our card generator we had added space between the type of card and its number, we split it here
        if (splits.length == 5) {
            String cardValue = splits[4];						// as we know the num value is in second part of the splitted array
            
            
            if (cardValue.matches("\\d+")) {				// Double check if the card value is numeric using the regex expression
                suit.set(splits[3]);							
                value.set(Integer.parseInt(cardValue));
                context.write(suit, value);					//Setting the context with key value pair, this will be later picked up by reduce.
            }
        }
    }
}
