import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class CardCountDriver {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Card Counting started");		//creates a new mapreduce job with the specified configuration 
        
        job.setJarByClass(CardCountDriver.class);					// setting the driver class
        job.setMapperClass(CountNumMapper.class);					// setting the mapper	
        job.setReducerClass(CounntNumReducer.class);				// setting the reducer

        job.setOutputKeyClass(Text.class);							
        job.setOutputValueClass(IntWritable.class);

        job.setInputFormatClass(TextInputFormat.class);					//setting input and output files formats
        job.setOutputFormatClass(TextOutputFormat.class);

        TextInputFormat.addInputPath(job, new Path(args[0]));			// getting the input path specified while writing jar command
        TextOutputFormat.setOutputPath(job, new Path(args[1]));			// getting the output path specified while writing jar command

        System.exit(job.waitForCompletion(true) ? 0 : 1);				// once job completed it will return and exit
    }
}
