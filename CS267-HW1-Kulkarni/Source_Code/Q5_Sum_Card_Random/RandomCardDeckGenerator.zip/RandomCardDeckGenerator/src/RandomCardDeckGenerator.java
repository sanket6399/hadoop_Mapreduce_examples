import java.io.*;
import java.util.*;

public class RandomCardDeckGenerator {
    public static void main(String[] args) {
    	/* This function generates card deck of given size 100/1000, then shuffles them and puts them in an input file*/
        Random random = new Random();
        
        List<String> total_card_list = new ArrayList<>();
        String[] weight = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        String[] type_of_cardsList = {"Clubs", "Diamonds", "Heart", "Spades"};
        int maxCardDecks = 1000; 				// We can change this value as per the inputs in HW. This can be made argument based as well

        for (int deck = 0; deck < maxCardDecks; deck++) {
        	List<String> cardsList = new ArrayList<>();
        	for (String type : type_of_cardsList) {
              for (String value : weight) {
                  cardsList.add("Deck Number " + deck + " " + type + " " + value);
              }
        	}
            for(int i = 0; i < 17; i++) {
            	int ranCard = random.nextInt(cardsList.size());
                cardsList.remove(ranCard);
            }
            total_card_list.addAll(cardsList);
        }
       
        Collections.shuffle(total_card_list);				 // Shuffle the card decks based on types and weights
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("rando_input_1000.txt"))) {
            for (String card : total_card_list) {
                writer.write(card + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}