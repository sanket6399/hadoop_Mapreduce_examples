#!/usr/bin/env python3

import sys

current_kmer = None
current_count = 0

# Read input from STDIN (standard input)
for line in sys.stdin:
    line = line.strip()  # Remove leading/trailing whitespaces

    # Split the line into k-mer and count
    kmer, count = line.split("\t", 1)

    # Convert count to an integer
    count = int(count)

    # If the k-mer is the same as the current one, increment the count
    if current_kmer == kmer:
        current_count += count
    else:
        # If it's a new k-mer, print the current k-mer and its count
        if current_kmer:
            print(f"{current_kmer}\t{current_count}")
        # Reset current k-mer and count
        current_kmer = kmer
        current_count = count

# Print the last k-mer and its count
if current_kmer:
    print(f"{current_kmer}\t{current_count}")

