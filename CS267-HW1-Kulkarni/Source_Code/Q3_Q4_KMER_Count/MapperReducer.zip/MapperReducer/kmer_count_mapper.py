#!/usr/bin/env python3

import sys

# Get the k-mer size from the command-line argument
if len(sys.argv) != 2:
    print("Usage: kmer_mapper.py <k>")
    sys.exit(1)

k = int(sys.argv[1])

# Read input from STDIN (standard input)
input_data = ""
for line in sys.stdin:
    if line.startswith('>') or line.startswith('<'):
        continue
    line = line.strip()  # Remove leading/trailing whitespaces
    line = line.replace(" ", "")  # Remove spaces in the input
    line = ''.join(e for e in line if e.isalnum())  # Remove non-alphanumeric characters
    input_data += line.upper()  # Convert to uppercase and append to the input_data

# Process the entire input as a single line
for i in range(len(input_data) - k + 1):
    kmer = input_data[i:i+k]  # Extract k-mer from the sequence
    print(f"{kmer}\t1")  # Output k-mer and count 1

